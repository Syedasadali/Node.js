# Calculator-
Simple and scientific calculator with the help of typeScript and javaScript,,!
