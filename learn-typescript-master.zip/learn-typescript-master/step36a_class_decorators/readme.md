Read this:
Chapter 8 of Learning TypeScript
http://www.amazon.com/Learning-TypeScript-Remo-H-Jansen/dp/1783985542/ref=sr_1_1

http://blog.wolksoftware.com/decorators-reflection-javascript-typescript
http://blog.wolksoftware.com/decorators-metadata-reflection-in-typescript-from-novice-to-expert-part-ii

Command:
tsc -target es5 -module commonjs -emitDecoratorMetadata -experimentalDecorators app.ts

Extra Reading:
http://blogs.msdn.com/b/typescript/archive/2015/04/30/announcing-typescript-1-5-beta.aspx
http://blog.wolksoftware.com/decorators-reflection-javascript-typescript