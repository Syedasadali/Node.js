Read the callback secition in the Mastering TypeScript Book 
http://www.amazon.com/Mastering-TypeScript-Nathan-Rozentals/dp/1784399663/