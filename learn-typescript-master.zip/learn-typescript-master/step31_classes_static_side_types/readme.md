Read "Difference between static/instance side of class" from:
http://www.typescriptlang.org/Handbook#interfaces-class-types