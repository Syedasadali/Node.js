; //starts with 0
var c = 1 /* Green */;
;
; //can assign values to all
var colorIndex = 4 /* "Blue" */;
console.log(colorIndex);
