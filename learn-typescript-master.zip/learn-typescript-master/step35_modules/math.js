function add(a, b) {
    return a + b;
}
exports.add = add;
function sub(c, d) {
    return c + d;
}
exports.sub = sub;
