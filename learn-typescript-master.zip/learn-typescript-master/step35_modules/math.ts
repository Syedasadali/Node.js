export function add(a:number, b:number) {
	return a + b;
}

export function sub(c: number, d: number){
	return c + d;
}
