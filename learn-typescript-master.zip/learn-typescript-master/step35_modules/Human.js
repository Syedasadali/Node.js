var Human = (function () {
    function Human() {
        this.name = "zia";
    }
    return Human;
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Human;
