var array1 = [5, 6, 7]; //correct syntax
console.log(array1[1]); //correct syntax
var array2 = [1, 2, 3]; //alternative correct syntax
var array3 = []; //correct syntax to define an empty array
