ES6 let and const are now part of TypeScript:
https://strongloop.com/strongblog/es6-variable-declarations/
https://github.com/Microsoft/TypeScript/wiki/What's-new-in-TypeScript
