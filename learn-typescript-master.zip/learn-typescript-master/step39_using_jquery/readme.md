Download jQuery from:
https://jquery.com/download/

Give these commands to install tsd globally
npm install tsd -g

tsd init
tsd install jquery --save


Read tsd docs:
https://github.com/DefinitelyTyped/tsd



