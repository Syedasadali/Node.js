Read:
http://www.typescriptlang.org/Handbook#interfaces-hybrid-types