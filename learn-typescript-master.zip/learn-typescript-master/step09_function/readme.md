Functions in chapter 2 of Mastering TypeScript book:
http://www.amazon.com/Mastering-TypeScript-Nathan-Rozentals/dp/1784399663/

Also Read:
http://www.codingdefined.com/2015/04/functions-in-typescript.html

https://basarat.gitbooks.io/typescript/content/docs/arrow-functions.html

http://www.typescriptlang.org/Handbook#functions
