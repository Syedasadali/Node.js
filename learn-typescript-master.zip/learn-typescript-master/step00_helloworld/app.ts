//For the latest specifications:
//https://github.com/Microsoft/TypeScript/blob/master/doc/spec.md

class Startup {
    public static main(): number {
        console.log('Hello World');
        return 0;
    }
}

Startup.main();