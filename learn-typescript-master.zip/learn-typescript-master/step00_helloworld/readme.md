For the latest specifications:
https://github.com/Microsoft/TypeScript/blob/master/doc/spec.md

Hello World Steps:

1. Install Node.js from https://nodejs.org/
2. Install TypeScript 1.6+ using Node Package Manager command (http://www.typescriptlang.org/#Download):  
			npm install -g typescript
3. Install VSCode from https://code.visualstudio.com/Download
4. Reading and transpile typescript http://blogs.msdn.com/b/typescript/archive/2015/04/30/using-typescript-in-visual-studio-code.aspx
5. Run transpiled javascript by running the following command:
		node app

		
Also Read:
https://code.visualstudio.com/Docs/languages/typescript