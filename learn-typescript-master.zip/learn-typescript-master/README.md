# Learn TypeScript 1.6+ in Baby Steps
We will learn TypeScript by taking small incremental steps. We are learning this language becuase Angular 2 is being built using TypeScript. We will use a combination of TypeScript and Angular 2 to build web apps. You can also start learning Angular 2 from:
https://github.com/panacloud/learn-angular2

Learn React using TypeScript:
https://github.com/panacloud/learn-react

You can also learn Node.js/Express using TypeScript from:
https://github.com/panacloud/learn-typed-express