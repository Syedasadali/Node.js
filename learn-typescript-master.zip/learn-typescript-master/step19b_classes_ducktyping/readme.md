Read:
https://visualstudiomagazine.com/articles/2015/02/01/datatyping-in-typescript.aspx
http://www.typescriptlang.org/Handbook#classes-classes
http://basarat.gitbooks.io/typescript/content/docs/classes.html

Nominative and structural type systems
http://en.wikipedia.org/wiki/Nominative_and_structural_type_systems
https://www.stevefenton.co.uk/Content/Blog/Date/201407/Blog/TypeScript-And-Structural-Verses-Nominal-Types/
http://www.slideshare.net/SmartLogic/introduction-to-type-script-by-sam-goldman-smartlogic

Please note that in 1.6 the concept of Duck Typing has changed a bit: https://github.com/Microsoft/TypeScript/pull/3823