Read:
https://github.com/Microsoft/TypeScript/issues/3578