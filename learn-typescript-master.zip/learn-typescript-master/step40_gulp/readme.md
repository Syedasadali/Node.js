Read:
1. Read the basics from http://david.nowinsky.net/gulp-book/
2. https://scotch.io/tutorials/automate-your-tasks-easily-with-gulp-js
3. https://www.airpair.com/typescript/posts/typescript-development-with-gulp-and-sublime-text
4. https://github.com/ivogabe/gulp-typescript
5. http://stackoverflow.com/questions/26079118/does-a-gulp-task-have-to-return-anything
6. https://github.com/gulpjs/gulp/blob/master/docs/API.md

Install Gulp globally ( https://github.com/gulpjs/gulp/blob/master/docs/getting-started.md ):
npm install gulp -g

Install node modules by:
npm install


On the command promt just type "gulp", now it will continuesly watch and generate JavaScript if there are any changes in TypeScript

To run:
node dest/app.js