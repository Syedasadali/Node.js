Read:
http://www.typescriptlang.org/Handbook#interfaces-extending-interfaces