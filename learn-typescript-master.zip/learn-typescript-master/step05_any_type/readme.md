any type in chapter 2 of Mastering TypeScript book:
http://www.amazon.com/Mastering-TypeScript-Nathan-Rozentals/dp/1784399663/

Also read:
https://tutorialstown.com/the-any-type-in-typescript/
http://stackoverflow.com/questions/18961203/typescript-any-vs-object