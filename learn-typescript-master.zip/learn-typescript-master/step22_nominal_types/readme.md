Read:
http://www.typescriptlang.org/Handbook#classes-privatepublic-modifiers
https://www.stevefenton.co.uk/Content/Blog/Date/201407/Blog/TypeScript-And-Structural-Verses-Nominal-Types/

Nominative and structural type systems
http://en.wikipedia.org/wiki/Nominative_and_structural_type_systems
http://www.slideshare.net/SmartLogic/introduction-to-type-script-by-sam-goldman-smartlogic