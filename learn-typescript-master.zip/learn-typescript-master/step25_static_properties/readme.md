Read:
http://www.typescriptlang.org/Handbook#classes-static-properties