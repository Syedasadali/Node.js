Read:
http://www.typescriptlang.org/Handbook#classes-privatepublic-modifiers
http://stackoverflow.com/questions/12713659/typescript-private-members