// var a : string = "hello";
// a = 10;

// var a : number = 10;
// a = 20;

// var a : boolean = true;
// a = "10";

// var a = "hello world";
// a = true;


// var a : any;
// a = "hello";
// a = 10;
// a = true;