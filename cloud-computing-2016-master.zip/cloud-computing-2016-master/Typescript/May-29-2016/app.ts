if(true){
    let a = 10;
   alert(a)
}
alert(a);
